// this is a simple wrapper for the test-sequence module

#include "test-sequence.h"
#include "sequence.h"

int main(void) {
  test_sequence();
}
